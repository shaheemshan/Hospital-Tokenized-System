import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_BASE_URL,
});

// Departments
export const getDepartments = () => api.get('/departments');
export const createDepartment = (data) => api.post('/departments', data);
export const deleteDepartment = (id) => api.delete(`/departments/${id}`);

// Tokens
export const createToken = (data) => api.post('/tokens', data);
export const getTokenById = (id) => api.get(`/tokens/${id}`);
export const getDepartmentStatus = (departmentId) => api.get(`/tokens/status/${departmentId}`);
export const getQueue = (departmentId) => api.get(`/tokens/queue/${departmentId}`);
export const callNextToken = (departmentId) => api.put(`/tokens/next/${departmentId}`);
export const callSpecificToken = (id) => api.put(`/tokens/${id}/call`);
export const completeToken = (id) => api.put(`/tokens/${id}/complete`);
export const skipToken = (id) => api.put(`/tokens/${id}/skip`);
export const getAllTokens = (departmentId) =>
  api.get('/tokens', { params: departmentId ? { department: departmentId } : {} });

export default api;
