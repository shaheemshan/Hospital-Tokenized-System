import React, { useEffect, useState, useCallback } from 'react';
import { getDepartments, getDepartmentStatus } from '../api';

function DisplayBoard() {
  const [departments, setDepartments] = useState([]);
  const [statuses, setStatuses] = useState({});

  const loadAll = useCallback(async () => {
    const deptRes = await getDepartments();
    setDepartments(deptRes.data);

    const results = await Promise.all(
      deptRes.data.map((dept) => getDepartmentStatus(dept._id).then((r) => [dept._id, r.data]))
    );
    const map = {};
    results.forEach(([id, data]) => {
      map[id] = data;
    });
    setStatuses(map);
  }, []);

  useEffect(() => {
    loadAll();
    const interval = setInterval(loadAll, 4000);
    return () => clearInterval(interval);
  }, [loadAll]);

  return (
    <div style={styles.wrapper}>
      <h1 style={styles.title}>Now Serving</h1>
      <div style={styles.grid}>
        {departments.map((dept) => {
          const s = statuses[dept._id] || {};
          return (
            <div key={dept._id} style={styles.card}>
              <h2 style={styles.deptName}>{dept.name}</h2>
              <div style={styles.tokenDisplay}>
                {s.currentlyServing ? s.currentlyServing.tokenCode : '---'}
              </div>
              <p style={styles.waitingCount}>
                {s.waiting ? s.waiting.length : 0} waiting
              </p>
              {s.waiting && s.waiting.length > 0 && (
                <p style={styles.nextUp}>
                  Next: {s.waiting.slice(0, 3).map((t) => t.tokenCode).join(', ')}
                </p>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

const styles = {
  wrapper: { background: '#0f172a', minHeight: '100vh', padding: 40 },
  title: { color: '#f8fafc', textAlign: 'center', fontSize: 36, marginBottom: 40 },
  grid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
    gap: 24,
    maxWidth: 1100,
    margin: '0 auto',
  },
  card: {
    background: '#1e293b',
    borderRadius: 16,
    padding: 28,
    textAlign: 'center',
    boxShadow: '0 4px 24px rgba(0,0,0,0.4)',
  },
  deptName: { color: '#94a3b8', fontSize: 18, marginBottom: 12, textTransform: 'uppercase', letterSpacing: 1 },
  tokenDisplay: { fontSize: 56, fontWeight: 800, color: '#38bdf8' },
  waitingCount: { color: '#cbd5e1', marginTop: 12, fontSize: 15 },
  nextUp: { color: '#64748b', fontSize: 13, marginTop: 4 },
};

export default DisplayBoard;
