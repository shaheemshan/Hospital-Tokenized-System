import React, { useEffect, useState, useCallback } from 'react';
import {
  getDepartments,
  createDepartment,
  getDepartmentStatus,
  callNextToken,
  completeToken,
  skipToken,
} from '../api';

function AdminDashboard() {
  const [departments, setDepartments] = useState([]);
  const [selectedDept, setSelectedDept] = useState('');
  const [status, setStatus] = useState({ currentlyServing: null, waiting: [] });
  const [newDeptName, setNewDeptName] = useState('');
  const [newDeptPrefix, setNewDeptPrefix] = useState('');
  const [message, setMessage] = useState('');

  const loadDepartments = useCallback(() => {
    getDepartments().then((res) => {
      setDepartments(res.data);
      if (!selectedDept && res.data.length > 0) setSelectedDept(res.data[0]._id);
    });
  }, [selectedDept]);

  const loadStatus = useCallback(() => {
    if (!selectedDept) return;
    getDepartmentStatus(selectedDept).then((res) => setStatus(res.data));
  }, [selectedDept]);

  useEffect(() => {
    loadDepartments();
  }, [loadDepartments]);

  useEffect(() => {
    loadStatus();
    const interval = setInterval(loadStatus, 4000);
    return () => clearInterval(interval);
  }, [loadStatus]);

  const handleCallNext = async () => {
    setMessage('');
    try {
      await callNextToken(selectedDept);
      loadStatus();
    } catch (err) {
      setMessage(err.response?.data?.message || 'No one is waiting.');
    }
  };

  const handleComplete = async (id) => {
    await completeToken(id);
    loadStatus();
  };

  const handleSkip = async (id) => {
    await skipToken(id);
    loadStatus();
  };

  const handleAddDepartment = async (e) => {
    e.preventDefault();
    if (!newDeptName || !newDeptPrefix) return;
    try {
      await createDepartment({ name: newDeptName, prefix: newDeptPrefix.toUpperCase() });
      setNewDeptName('');
      setNewDeptPrefix('');
      loadDepartments();
    } catch (err) {
      setMessage(err.response?.data?.message || 'Could not add department.');
    }
  };

  return (
    <div style={styles.wrapper}>
      <h2 style={styles.heading}>Counter / Admin Dashboard</h2>

      <div style={styles.row}>
        <label style={styles.label}>Department:</label>
        <select
          style={styles.select}
          value={selectedDept}
          onChange={(e) => setSelectedDept(e.target.value)}
        >
          {departments.map((dept) => (
            <option key={dept._id} value={dept._id}>
              {dept.name}
            </option>
          ))}
        </select>
      </div>

      {message && <p style={styles.message}>{message}</p>}

      <div style={styles.grid}>
        <div style={styles.panel}>
          <h3 style={styles.panelTitle}>Currently Serving</h3>
          {status.currentlyServing ? (
            <div>
              <div style={styles.currentToken}>{status.currentlyServing.tokenCode}</div>
              <p style={styles.name}>{status.currentlyServing.patientName}</p>
              <button style={styles.completeBtn} onClick={() => handleComplete(status.currentlyServing._id)}>
                Mark Completed
              </button>
              <button style={styles.skipBtn} onClick={() => handleSkip(status.currentlyServing._id)}>
                Skip / No Show
              </button>
            </div>
          ) : (
            <p style={styles.empty}>No one is being served right now.</p>
          )}
          <button style={styles.callNextBtn} onClick={handleCallNext}>
            Call Next Token
          </button>
        </div>

        <div style={styles.panel}>
          <h3 style={styles.panelTitle}>Waiting Queue ({status.waiting.length})</h3>
          {status.waiting.length === 0 ? (
            <p style={styles.empty}>Queue is empty.</p>
          ) : (
            <ul style={styles.queueList}>
              {status.waiting.map((t, idx) => (
                <li key={t._id} style={styles.queueItem}>
                  <span style={styles.queuePos}>{idx + 1}</span>
                  <span style={styles.queueCode}>{t.tokenCode}</span>
                  <span style={styles.queueName}>{t.patientName}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      <div style={styles.panel}>
        <h3 style={styles.panelTitle}>Add Department</h3>
        <form onSubmit={handleAddDepartment} style={styles.addForm}>
          <input
            style={styles.smallInput}
            placeholder="Department name"
            value={newDeptName}
            onChange={(e) => setNewDeptName(e.target.value)}
          />
          <input
            style={{ ...styles.smallInput, width: 100 }}
            placeholder="Prefix (e.g. GM)"
            value={newDeptPrefix}
            onChange={(e) => setNewDeptPrefix(e.target.value)}
          />
          <button style={styles.addBtn} type="submit">
            Add
          </button>
        </form>
      </div>
    </div>
  );
}

const styles = {
  wrapper: { maxWidth: 900, margin: '32px auto', padding: '0 16px' },
  heading: { color: '#111827' },
  row: { display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20 },
  label: { fontSize: 15, color: '#374151' },
  select: { padding: '8px 12px', borderRadius: 8, border: '1px solid #d1d5db', fontSize: 15 },
  message: { color: '#b45309', background: '#fef3c7', padding: '8px 12px', borderRadius: 8 },
  grid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginBottom: 20 },
  panel: {
    background: '#fff',
    borderRadius: 12,
    padding: 24,
    boxShadow: '0 4px 20px rgba(0,0,0,0.06)',
  },
  panelTitle: { marginTop: 0, color: '#111827', fontSize: 17 },
  currentToken: {
    fontSize: 40,
    fontWeight: 700,
    color: '#1d4ed8',
    background: '#eff6ff',
    borderRadius: 10,
    padding: '16px 0',
    textAlign: 'center',
  },
  name: { textAlign: 'center', color: '#374151', margin: '10px 0' },
  empty: { color: '#9ca3af', fontStyle: 'italic' },
  callNextBtn: {
    marginTop: 16,
    width: '100%',
    padding: '12px',
    background: '#2563eb',
    color: '#fff',
    border: 'none',
    borderRadius: 8,
    fontSize: 15,
    fontWeight: 600,
    cursor: 'pointer',
  },
  completeBtn: {
    width: '100%',
    padding: '10px',
    marginTop: 8,
    background: '#16a34a',
    color: '#fff',
    border: 'none',
    borderRadius: 8,
    cursor: 'pointer',
  },
  skipBtn: {
    width: '100%',
    padding: '10px',
    marginTop: 8,
    background: '#f3f4f6',
    color: '#111827',
    border: '1px solid #d1d5db',
    borderRadius: 8,
    cursor: 'pointer',
  },
  queueList: { listStyle: 'none', padding: 0, margin: 0, maxHeight: 260, overflowY: 'auto' },
  queueItem: {
    display: 'flex',
    alignItems: 'center',
    gap: 12,
    padding: '8px 0',
    borderBottom: '1px solid #f3f4f6',
  },
  queuePos: {
    width: 24,
    height: 24,
    borderRadius: '50%',
    background: '#e5e7eb',
    color: '#374151',
    fontSize: 12,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  queueCode: { fontWeight: 700, color: '#1d4ed8' },
  queueName: { color: '#6b7280' },
  addForm: { display: 'flex', gap: 10 },
  smallInput: { flex: 1, padding: '10px 12px', borderRadius: 8, border: '1px solid #d1d5db' },
  addBtn: {
    padding: '10px 20px',
    background: '#111827',
    color: '#fff',
    border: 'none',
    borderRadius: 8,
    cursor: 'pointer',
  },
};

export default AdminDashboard;
