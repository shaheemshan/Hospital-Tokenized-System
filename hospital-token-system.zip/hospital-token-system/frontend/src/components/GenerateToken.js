import React, { useEffect, useState } from 'react';
import { getDepartments, createToken, getTokenById } from '../api';

function GenerateToken() {
  const [departments, setDepartments] = useState([]);
  const [selectedDept, setSelectedDept] = useState('');
  const [patientName, setPatientName] = useState('');
  const [patientPhone, setPatientPhone] = useState('');
  const [issuedToken, setIssuedToken] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    getDepartments()
      .then((res) => {
        setDepartments(res.data);
        if (res.data.length > 0) setSelectedDept(res.data[0]._id);
      })
      .catch(() => setError('Could not load departments. Is the backend running?'));
  }, []);

  // Poll for queue position updates on the issued token
  useEffect(() => {
    if (!issuedToken) return;
    const interval = setInterval(() => {
      getTokenById(issuedToken.token._id)
        .then((res) => setIssuedToken(res.data))
        .catch(() => {});
    }, 5000);
    return () => clearInterval(interval);
  }, [issuedToken]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    if (!patientName || !selectedDept) {
      setError('Please enter your name and select a department.');
      return;
    }
    setLoading(true);
    try {
      const res = await createToken({
        patientName,
        patientPhone,
        departmentId: selectedDept,
      });
      setIssuedToken(res.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Something went wrong.');
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setIssuedToken(null);
    setPatientName('');
    setPatientPhone('');
  };

  if (issuedToken) {
    const { token, position } = issuedToken;
    return (
      <div style={styles.card}>
        <h2 style={styles.heading}>Your Token</h2>
        <div style={styles.tokenBox}>{token.tokenCode}</div>
        <p style={styles.info}>Patient: {token.patientName}</p>
        <p style={styles.info}>
          Status: <strong style={{ textTransform: 'capitalize' }}>{token.status}</strong>
        </p>
        {token.status === 'waiting' && (
          <p style={styles.info}>
            People ahead of you: <strong>{position - 1}</strong>
          </p>
        )}
        {token.status === 'called' && (
          <p style={{ ...styles.info, color: '#16a34a', fontWeight: 'bold' }}>
            Please proceed to the counter now!
          </p>
        )}
        {token.status === 'completed' && (
          <p style={{ ...styles.info, color: '#6b7280' }}>Your visit is complete. Thank you!</p>
        )}
        <button style={styles.buttonSecondary} onClick={reset}>
          Generate Another Token
        </button>
      </div>
    );
  }

  return (
    <div style={styles.card}>
      <h2 style={styles.heading}>Get Your Token</h2>
      {error && <p style={styles.error}>{error}</p>}
      <form onSubmit={handleSubmit}>
        <label style={styles.label}>Department</label>
        <select
          style={styles.input}
          value={selectedDept}
          onChange={(e) => setSelectedDept(e.target.value)}
        >
          {departments.map((dept) => (
            <option key={dept._id} value={dept._id}>
              {dept.name}
            </option>
          ))}
        </select>

        <label style={styles.label}>Full Name</label>
        <input
          style={styles.input}
          type="text"
          value={patientName}
          onChange={(e) => setPatientName(e.target.value)}
          placeholder="e.g. John Doe"
        />

        <label style={styles.label}>Phone (optional)</label>
        <input
          style={styles.input}
          type="tel"
          value={patientPhone}
          onChange={(e) => setPatientPhone(e.target.value)}
          placeholder="e.g. 9876543210"
        />

        <button style={styles.button} type="submit" disabled={loading}>
          {loading ? 'Generating...' : 'Generate Token'}
        </button>
      </form>
    </div>
  );
}

const styles = {
  card: {
    maxWidth: 420,
    margin: '40px auto',
    background: '#fff',
    borderRadius: 12,
    padding: 32,
    boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
  },
  heading: { marginTop: 0, color: '#111827' },
  label: { display: 'block', marginTop: 16, marginBottom: 6, fontSize: 14, color: '#374151' },
  input: {
    width: '100%',
    padding: '10px 12px',
    borderRadius: 8,
    border: '1px solid #d1d5db',
    fontSize: 15,
  },
  button: {
    marginTop: 24,
    width: '100%',
    padding: '12px',
    background: '#2563eb',
    color: '#fff',
    border: 'none',
    borderRadius: 8,
    fontSize: 16,
    fontWeight: 600,
    cursor: 'pointer',
  },
  buttonSecondary: {
    marginTop: 20,
    width: '100%',
    padding: '10px',
    background: '#f3f4f6',
    color: '#111827',
    border: '1px solid #d1d5db',
    borderRadius: 8,
    fontSize: 14,
    cursor: 'pointer',
  },
  tokenBox: {
    fontSize: 48,
    fontWeight: 700,
    textAlign: 'center',
    padding: '24px 0',
    background: '#eff6ff',
    color: '#1d4ed8',
    borderRadius: 12,
    letterSpacing: 2,
  },
  info: { fontSize: 15, color: '#374151' },
  error: { color: '#dc2626', fontSize: 14 },
};

export default GenerateToken;
