import React from 'react';
import { BrowserRouter, Routes, Route, Link, useLocation } from 'react-router-dom';
import GenerateToken from './components/GenerateToken';
import AdminDashboard from './components/AdminDashboard';
import DisplayBoard from './components/DisplayBoard';

function NavBar() {
  const location = useLocation();
  if (location.pathname === '/display') return null; // hide nav on the display board

  const linkStyle = (path) => ({
    padding: '10px 18px',
    textDecoration: 'none',
    color: location.pathname === path ? '#fff' : '#374151',
    background: location.pathname === path ? '#2563eb' : 'transparent',
    borderRadius: 8,
    fontWeight: 600,
    fontSize: 14,
  });

  return (
    <nav style={navStyles.bar}>
      <div style={navStyles.brand}>🏥 Hospital Token System</div>
      <div style={navStyles.links}>
        <Link to="/" style={linkStyle('/')}>Get Token</Link>
        <Link to="/admin" style={linkStyle('/admin')}>Admin Panel</Link>
        <Link to="/display" style={linkStyle('/display')}>Display Board</Link>
      </div>
    </nav>
  );
}

const navStyles = {
  bar: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '14px 32px',
    background: '#fff',
    boxShadow: '0 2px 8px rgba(0,0,0,0.05)',
  },
  brand: { fontWeight: 700, fontSize: 18, color: '#111827' },
  links: { display: 'flex', gap: 10 },
};

function App() {
  return (
    <BrowserRouter>
      <NavBar />
      <Routes>
        <Route path="/" element={<GenerateToken />} />
        <Route path="/admin" element={<AdminDashboard />} />
        <Route path="/display" element={<DisplayBoard />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
