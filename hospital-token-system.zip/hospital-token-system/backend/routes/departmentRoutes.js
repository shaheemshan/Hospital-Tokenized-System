const express = require('express');
const router = express.Router();
const Department = require('../models/Department');

// GET all departments
router.get('/', async (req, res) => {
  try {
    const departments = await Department.find().populate('currentlyServing');
    res.json(departments);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST create a new department
router.post('/', async (req, res) => {
  try {
    const { name, prefix } = req.body;
    if (!name || !prefix) {
      return res.status(400).json({ message: 'name and prefix are required' });
    }
    const existing = await Department.findOne({ name });
    if (existing) {
      return res.status(409).json({ message: 'Department already exists' });
    }
    const department = await Department.create({ name, prefix });
    res.status(201).json(department);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// DELETE a department
router.delete('/:id', async (req, res) => {
  try {
    await Department.findByIdAndDelete(req.params.id);
    res.json({ message: 'Department removed' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
