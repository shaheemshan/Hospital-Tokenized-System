const express = require('express');
const router = express.Router();
const Token = require('../models/Token');
const Department = require('../models/Department');

// POST /api/tokens - generate a new token for a patient
router.post('/', async (req, res) => {
  try {
    const { patientName, patientPhone, departmentId } = req.body;

    if (!patientName || !departmentId) {
      return res.status(400).json({ message: 'patientName and departmentId are required' });
    }

    const department = await Department.findById(departmentId);
    if (!department) {
      return res.status(404).json({ message: 'Department not found' });
    }

    const nextNumber = department.lastTokenNumber + 1;
    department.lastTokenNumber = nextNumber;
    await department.save();

    const tokenCode = `${department.prefix}-${String(nextNumber).padStart(3, '0')}`;

    const token = await Token.create({
      tokenCode,
      tokenNumber: nextNumber,
      patientName,
      patientPhone,
      department: department._id,
      status: 'waiting',
    });

    // Compute position in queue (how many waiting tokens are ahead)
    const position = await Token.countDocuments({
      department: department._id,
      status: 'waiting',
      tokenNumber: { $lt: nextNumber },
    });

    res.status(201).json({ token, position: position + 1 });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/tokens/queue/:departmentId - list of waiting tokens for a department
router.get('/queue/:departmentId', async (req, res) => {
  try {
    const tokens = await Token.find({
      department: req.params.departmentId,
      status: 'waiting',
    }).sort({ tokenNumber: 1 });
    res.json(tokens);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/tokens/status/:departmentId - currently serving + next few waiting
router.get('/status/:departmentId', async (req, res) => {
  try {
    const department = await Department.findById(req.params.departmentId).populate('currentlyServing');
    if (!department) return res.status(404).json({ message: 'Department not found' });

    const waiting = await Token.find({
      department: req.params.departmentId,
      status: 'waiting',
    }).sort({ tokenNumber: 1 }).limit(5);

    res.json({
      currentlyServing: department.currentlyServing,
      waiting,
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/tokens/:id - check status/position of a single token
router.get('/:id', async (req, res) => {
  try {
    const token = await Token.findById(req.params.id).populate('department');
    if (!token) return res.status(404).json({ message: 'Token not found' });

    const position = await Token.countDocuments({
      department: token.department._id,
      status: 'waiting',
      tokenNumber: { $lt: token.tokenNumber },
    });

    res.json({ token, position: token.status === 'waiting' ? position + 1 : 0 });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// PUT /api/tokens/:id/call - call this token in (mark as currently serving)
router.put('/:id/call', async (req, res) => {
  try {
    const token = await Token.findById(req.params.id);
    if (!token) return res.status(404).json({ message: 'Token not found' });

    token.status = 'called';
    token.calledAt = new Date();
    await token.save();

    await Department.findByIdAndUpdate(token.department, { currentlyServing: token._id });

    res.json(token);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// PUT /api/tokens/:id/complete - mark token as completed
router.put('/:id/complete', async (req, res) => {
  try {
    const token = await Token.findById(req.params.id);
    if (!token) return res.status(404).json({ message: 'Token not found' });

    token.status = 'completed';
    token.completedAt = new Date();
    await token.save();

    const dept = await Department.findById(token.department);
    if (dept.currentlyServing && dept.currentlyServing.toString() === token._id.toString()) {
      dept.currentlyServing = null;
      await dept.save();
    }

    res.json(token);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// PUT /api/tokens/:id/skip - skip a token (patient not present)
router.put('/:id/skip', async (req, res) => {
  try {
    const token = await Token.findById(req.params.id);
    if (!token) return res.status(404).json({ message: 'Token not found' });

    token.status = 'skipped';
    await token.save();

    const dept = await Department.findById(token.department);
    if (dept.currentlyServing && dept.currentlyServing.toString() === token._id.toString()) {
      dept.currentlyServing = null;
      await dept.save();
    }

    res.json(token);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// PUT /api/tokens/next/:departmentId - call the next waiting token automatically
router.put('/next/:departmentId', async (req, res) => {
  try {
    const nextToken = await Token.findOne({
      department: req.params.departmentId,
      status: 'waiting',
    }).sort({ tokenNumber: 1 });

    if (!nextToken) {
      return res.status(404).json({ message: 'No patients waiting in queue' });
    }

    nextToken.status = 'called';
    nextToken.calledAt = new Date();
    await nextToken.save();

    await Department.findByIdAndUpdate(req.params.departmentId, { currentlyServing: nextToken._id });

    res.json(nextToken);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/tokens - full history/list (admin), optional ?department= filter
router.get('/', async (req, res) => {
  try {
    const filter = {};
    if (req.query.department) filter.department = req.query.department;
    const tokens = await Token.find(filter)
      .populate('department')
      .sort({ createdAt: -1 })
      .limit(100);
    res.json(tokens);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
