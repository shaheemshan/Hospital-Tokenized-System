// Run with: node seed.js
// Creates a starter set of hospital departments so you can test the app right away.
require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('./config/db');
const Department = require('./models/Department');

const defaultDepartments = [
  { name: 'General Medicine', prefix: 'GM' },
  { name: 'Cardiology', prefix: 'CD' },
  { name: 'Orthopedics', prefix: 'OR' },
  { name: 'Pediatrics', prefix: 'PD' },
];

const seed = async () => {
  await connectDB();
  for (const dept of defaultDepartments) {
    const exists = await Department.findOne({ name: dept.name });
    if (!exists) {
      await Department.create(dept);
      console.log(`Created department: ${dept.name}`);
    } else {
      console.log(`Already exists: ${dept.name}`);
    }
  }
  console.log('Seeding complete.');
  mongoose.connection.close();
};

seed();
