const mongoose = require('mongoose');

const departmentSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    prefix: {
      type: String,
      required: true,
      uppercase: true,
      trim: true,
    },
    lastTokenNumber: {
      type: Number,
      default: 0,
    },
    currentlyServing: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Token',
      default: null,
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Department', departmentSchema);
