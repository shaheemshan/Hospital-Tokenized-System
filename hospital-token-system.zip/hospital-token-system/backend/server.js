require('dotenv').config();
const express = require('express');
const cors = require('cors');
const connectDB = require('./config/db');

const departmentRoutes = require('./routes/departmentRoutes');
const tokenRoutes = require('./routes/tokenRoutes');

const app = express();

connectDB();

app.use(cors());
app.use(express.json());

app.use('/api/departments', departmentRoutes);
app.use('/api/tokens', tokenRoutes);

app.get('/', (req, res) => {
  res.json({ message: 'Hospital Token System API is running' });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
