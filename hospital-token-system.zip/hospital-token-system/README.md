# Hospital Token System (MERN Stack)

A queue/token management system for hospitals, built with MongoDB, Express, React, and Node.js.

## Features

- **Patients** generate a token for a department and see their live queue position.
- **Counter staff / Admins** call the next token, mark visits complete, skip no-shows, and add new departments.
- **Display Board** — a big-screen view showing "Now Serving" for every department, auto-refreshing.

## Project Structure

```
hospital-token-system/
├── backend/          Express + MongoDB API
│   ├── config/       Database connection
│   ├── models/       Mongoose schemas (Token, Department)
│   ├── routes/       API route handlers
│   ├── seed.js       Optional script to create starter departments
│   └── server.js     App entry point
└── frontend/         React app
    └── src/
        ├── components/   GenerateToken, AdminDashboard, DisplayBoard
        ├── api.js         Axios API client
        └── App.js         Routes and navigation
```

## Prerequisites

- Node.js (v18+ recommended)
- MongoDB running locally (or a MongoDB Atlas connection string)

## Setup

### 1. Backend

```bash
cd backend
npm install
cp .env.example .env
# edit .env if your MongoDB URI or port is different
npm run dev
```

The API runs at `http://localhost:5000`.

Optional — seed a few default departments (General Medicine, Cardiology, Orthopedics, Pediatrics):

```bash
node seed.js
```

### 2. Frontend

Open a new terminal:

```bash
cd frontend
npm install
cp .env.example .env
npm start
```

The app opens at `http://localhost:3000`.

## Usage

- **`/`** — Patients enter their name and department to receive a token (e.g. `GM-001`) and see their live position in line.
- **`/admin`** — Staff view: see who's currently being served, call the next token, mark tokens complete/skipped, and add new departments.
- **`/display`** — Full-screen board intended for a waiting-room TV, showing the currently-serving token and next-up tokens for every department.

## API Overview

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/departments` | List all departments |
| POST | `/api/departments` | Create a department `{ name, prefix }` |
| POST | `/api/tokens` | Create a token `{ patientName, patientPhone, departmentId }` |
| GET | `/api/tokens/status/:departmentId` | Currently serving + upcoming tokens |
| GET | `/api/tokens/:id` | Single token status + queue position |
| PUT | `/api/tokens/next/:departmentId` | Call the next waiting token |
| PUT | `/api/tokens/:id/call` | Mark a specific token as called |
| PUT | `/api/tokens/:id/complete` | Mark a token as completed |
| PUT | `/api/tokens/:id/skip` | Mark a token as skipped/no-show |

## Notes

- This is a functional starting point — for production use, add authentication for the admin panel, input validation/sanitization, and HTTPS.
- Token numbers reset only if you manually reset `lastTokenNumber` on a department in the database; there's no automatic daily reset built in yet, but it's a natural next feature to add.
